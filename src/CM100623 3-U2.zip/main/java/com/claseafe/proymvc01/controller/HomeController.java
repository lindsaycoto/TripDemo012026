package com.claseafe.proymvc01.controller;
import org.springframework.beans.factory.annotation.Autowired;
import com.claseafe.proymvc01.service.ITripService;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.LinkedList;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;

import java.text.SimpleDateFormat;
import java.text.ParseException;
import com.claseafe.proymvc01.model.Trip;

@Controller
public class HomeController {
	
	@Autowired
	private ITripService tripService;
	
	@GetMapping ("/")
	public String mostrarHome (Model model) {
	
			List<Trip> lista = tripService.buscarTodos();
			model.addAttribute("trips", lista);
			
			return "home";
			
	}
		
	@GetMapping ("/detalle")
	public String mostrarDetalle(Model model) {
		Trip trip= new Trip();
		trip.setNombre ("Rapel en Volcatenando");
		trip.setDescripcion("Aventa rapel en un circuito conectado en las ...");
		trip.setFecha (new Date());
		trip.setCosto (10.0);
		model.addAttribute("trip", trip);
		
		return "detalle";
	}
	
	
	
	@GetMapping ("/listado")
	public String mostrarListado(Model model) {
		List<String> lista = new LinkedList<String>();
		lista.add("En la Montaña");
		lista.add("En la Ciudad");
		lista.add("En los pueblos");
		lista.add("En las playas");
		model.addAttribute("listadoTrips", lista);
		
		return "listado";
	}
	
	@GetMapping ("/view/{id}")
	public String verDetalle(@PathVariable("id") int idTrip, Model model) {
		Trip trip = tripService.buscarPorId(idTrip);
		System.out.println("ID de Trip es: "+idTrip);
		model.addAttribute("trip",trip);
		
		return "detalle";
	}
	
	
	private List<Trip>getTrip(){
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		List<Trip> lista = new LinkedList <Trip>();
		try {
			Trip trip1=new Trip();
			trip1.setId(1);
			trip1.setNombre ("Rapel en Volcatenando");
			trip1.setDescripcion ("Hacer rapel en los cirucitos del Volcatenando");
			trip1.setFecha (sdf.parse ("10-05-2022"));
			trip1.setCosto (5.0);
			trip1.setDestacado(1);
			trip1.setCalificacion(5);
			trip1.setImagen("trip01.png");
			
			Trip trip2=new Trip();
			trip2.setId(2);
			trip2.setNombre ("Deslizadero en El Picnic");
			trip2.setDescripcion ("Deslizarte en un divertido tobogan sobre la colina");
			trip2.setFecha (sdf.parse ("10-05-2022"));
			trip2.setCosto (5.0);
			trip2.setDestacado(1);
			trip2.setCalificacion(3);
			trip2.setImagen("trip02.png");
			
			Trip trip3=new Trip();
			trip3.setId(3);
			trip3.setNombre ("Comida y flores");
			trip3.setDescripcion ("Disfrutar en un amplio jardin en el cual podras comprar");
			trip3.setFecha (sdf.parse ("10-05-2022"));
			trip3.setCosto (1.0);
			trip3.setDestacado(0);
			trip3.setCalificacion(7);
			trip3.setImagen("trip03.png");
			
			Trip trip4=new Trip();
			trip4.setId (4);
			trip4.setNombre ("Caminatas");
			trip4.setDescripcion ("Disfruta hacer senderismo por las montañas chalatecas");
			trip4.setFecha (sdf.parse ("01-02-2022"));
			trip4.setCosto (1.0);
			trip4.setDestacado(1);
			trip4.setCalificacion(10);
			
			Trip trip5 = new Trip();
			trip5.setId(5);
			trip5.setNombre("Tour en bicicleta extrema");
			trip5.setDescripcion("Recorrido extremo por senderos naturales");
			trip5.setFecha(sdf.parse("12-03-2022"));
			trip5.setCosto(3.0);
			trip5.setDestacado(1);
			trip5.setCalificacion(4);

			Trip trip6 = new Trip();
			trip6.setId(6);
			trip6.setNombre("Camping nocturno");
			trip6.setDescripcion("Noche bajo las estrellas en la montaña");
			trip6.setFecha(sdf.parse("15-04-2022"));
			trip6.setCosto(4.0);
			trip6.setDestacado(0);
			trip6.setCalificacion(6);

			Trip trip7 = new Trip();
			trip7.setId(7);
			trip7.setNombre("Surf en la playa");
			trip7.setDescripcion("Clases básicas de surf en la playa");
			trip7.setFecha(sdf.parse("20-06-2022"));
			trip7.setCosto(8.0);
			trip7.setDestacado(1);
			trip7.setCalificacion(5);
			
			lista.add(trip1);
			lista.add(trip2);
			lista.add(trip3);
			lista.add(trip4);
			lista.add(trip5);
			lista.add(trip6);
			lista.add(trip7);
			
			
		} catch (ParseException e) {
			System.out.println	(e.getMessage());
		
		}
		return lista;
		
	
	}
	
}
	


